package com.example.budgetnestprototype

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class AddCategoryActivity : AppCompatActivity() {

    private lateinit var etNewCategory: EditText
    private lateinit var btnSaveCategory: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_category)

        // Initialize the views
        etNewCategory = findViewById(R.id.etNewCategory)
        btnSaveCategory = findViewById(R.id.btnSaveCategory)

        // Set up button click listener
        btnSaveCategory.setOnClickListener {
            val newCategory = etNewCategory.text.toString().trim() // Trim the input to avoid spaces
            if (newCategory.isNotEmpty()) {
                val uid = FirebaseAuth.getInstance().currentUser?.uid
                if (uid != null) {
                    val ref = FirebaseDatabase.getInstance().getReference("users/$uid/categories")
                    ref.child(newCategory).setValue(true)
                        .addOnSuccessListener {
                            Toast.makeText(this, "Category saved successfully!", Toast.LENGTH_SHORT)
                                .show()
                            finish() // Close the activity and return to the previous one
                        }
                }
            } else {
                // Show error if input is empty
                etNewCategory.error = "Category name cannot be empty"
            }
        }
    }
}

