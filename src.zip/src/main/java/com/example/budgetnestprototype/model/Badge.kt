package com.example.budgetnestprototype.model

import androidx.annotation.DrawableRes

data class Badge(
    val id: String,
    val name: String,
    val description: String,
    @DrawableRes val iconResId: Int,
    var isUnlocked: Boolean = false
)
