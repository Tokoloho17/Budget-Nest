package com.example.budgetnestprototype.model

data class CategoryGoal(
    val category: String = "",
    val minGoal: Double = 0.0,
    val maxGoal: Double = 0.0
)
