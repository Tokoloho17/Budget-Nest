package com.example.budgetnestprototype.model

data class Expense(
    val category: String = "",
    val amount: Double = 0.0,
    val timestamp: Long = 0L
)
