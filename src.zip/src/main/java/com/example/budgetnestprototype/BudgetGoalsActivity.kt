package com.example.budgetnestprototype

import android.content.Context
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.room.Database
import com.example.budgetnestprototype.data.Expense
import com.example.budgetnestprototype.data.ExpenseRepo
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.utils.ColorTemplate
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlin.math.exp

class BudgetGoalsActivity : AppCompatActivity() {

    private lateinit var pieChart: PieChart
    private var minGoal = 0
    private var maxGoal = 0
    private lateinit var minGoalInput: EditText
    private lateinit var maxGoalInput: EditText
    private lateinit var saveGoal: Button
    //private var totalExpense = 0f

    private lateinit var database: DatabaseReference
    private lateinit var auth: FirebaseAuth
    private val expenseEntries = ArrayList<PieEntry>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_budget_goals)

        minGoalInput = findViewById(R.id.addMinGoal)
        maxGoalInput = findViewById(R.id.addMaxGoal)
        saveGoal = findViewById(R.id.saveGoalBtn)
        pieChart = findViewById(R.id.pieChart)

        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().reference

        loadSavedGoals()
        loadChartData()

        saveGoal.setOnClickListener {
            val uid = auth.currentUser?.uid ?: return@setOnClickListener
            minGoal = minGoalInput.text.toString().toIntOrNull() ?: 0
            maxGoal = maxGoalInput.text.toString().toIntOrNull() ?: 0

            val goalsMap = mapOf("minGoal" to minGoal, "maxGoal" to maxGoal)
            database.child("users").child(uid).child("budgetGoals").setValue(goalsMap)
                .addOnSuccessListener {
                    Toast.makeText(this, "Goals saved!", Toast.LENGTH_SHORT).show()
                    loadChartData() // refresh chart
                }
        }
    }
    private fun loadSavedGoals() {
        val uid = auth.currentUser?.uid ?: return
        database.child("users").child(uid).child("budgetGoals").addListenerForSingleValueEvent(
            object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    minGoal = snapshot.child("minGoal").getValue(Int::class.java) ?: 0
                    maxGoal = snapshot.child("maxGoal").getValue(Int::class.java) ?: 0
                    minGoalInput.setText(minGoal.toString())
                    maxGoalInput.setText(maxGoal.toString())
    }
                override fun onCancelled(error: DatabaseError) {}
            })
    }

    private fun loadChartData() {
        val uid = auth.currentUser?.uid ?: return
        database.child("users").child(uid).child("expenses")
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val categoryTotals = mutableMapOf<String, Float>()
                    for (expenseSnapshot in snapshot.children) {
                        val expense = expenseSnapshot.getValue(Expense::class.java)
                        if (expense != null) {
                            val current = categoryTotals.getOrDefault(expense.category, 0f)
                            categoryTotals[expense.category] = current + (expense.amount.toFloatOrNull() ?: 0f)
                        }
        }

        val entries = categoryTotals.map { PieEntry(it.value, it.key) }
        val dataSet = PieDataSet(entries, "Expenses")
        dataSet.colors = ColorTemplate.MATERIAL_COLORS.toList()
        val pieData = PieData(dataSet)
        pieChart.data = pieData
        pieChart.invalidate()
    }
                override fun onCancelled(error: DatabaseError) {}
            })
    }
}
