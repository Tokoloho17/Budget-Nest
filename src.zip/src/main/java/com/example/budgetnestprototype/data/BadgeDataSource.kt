package com.example.budgetnestprototype.data

import com.example.budgetnestprototype.R
import com.example.budgetnestprototype.model.Badge
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

class BadgeDataSource {
    // Thread-safe mutable list with var
    private var badges: MutableList<Badge> = mutableListOf()
    private val lock = ReentrantLock()

    // Public immutable view
    val allBadges: List<Badge>
        get() = lock.withLock { badges.toList() }

    init {
        lock.withLock {
            badges = mutableListOf(
                Badge(
                    id = "budget_master",
                    name = "Budget Master",
                    description = "Stayed within budget all month",
                    iconResId = R.drawable.ic_budget_master,
                    isUnlocked = false
                ),
                Badge(
                    id = "daily_logger",
                    name = "Daily Logger",
                    description = "Logged expenses 7 days in a row",
                    iconResId = R.drawable.ic_daily_logger,
                    isUnlocked = false
                )
            )
        }
    }

    fun unlockBadge(badgeId: String): Boolean {
        lock.withLock {
            return badges.find { it.id == badgeId }?.let {
                it.isUnlocked = true
                true
            } ?: false
        }
    }

    fun replaceAllBadges(newBadges: List<Badge>) {
        lock.withLock {
            badges = newBadges.toMutableList()
        }
    }

    fun getBadge(badgeId: String): Badge? {
        return lock.withLock {
            badges.find { it.id == badgeId }
        }
    }

    fun getBadges(): List<Badge> {
        return allBadges
    }
}
