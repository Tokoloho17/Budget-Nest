package com.example.budgetnestprototype.data

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import javax.security.auth.callback.Callback

object ExpenseRepo {
    private val database: DatabaseReference = FirebaseDatabase.getInstance().reference
    private val currentUser = FirebaseAuth.getInstance().currentUser

    fun addExpense(expense: Expense) {
        currentUser?.let { user ->
            val userExpensesRef = database.child("expenses").child(user.uid)
            val newExpenseRef = userExpensesRef.push() // unique ID
            newExpenseRef.setValue(expense)
        }
    }

    fun getExpenses(callback: (List<Expense>) -> Unit) {
        currentUser?.let { user ->
            val userExpensesRef = database.child("expenses").child(user.uid)
            userExpensesRef.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val expenses = mutableListOf<Expense>()
                    for (child in snapshot.children) {
                        child.getValue(Expense::class.java)?.let { expenses.add(it) }
                    }
                    callback(expenses)
                }

                override fun onCancelled(error: DatabaseError) {
                    callback(emptyList())
                }
            })
        }
    }

    fun clearExpenses() {
        currentUser?.let { user ->
            database.child("expenses").child(user.uid).removeValue()
        }
    }
}

