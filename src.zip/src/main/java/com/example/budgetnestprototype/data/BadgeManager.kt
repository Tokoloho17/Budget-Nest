package com.example.budgetnestprototype.data
import com.example.budgetnestprototype.model.Badge

class BadgeManager(private val dataSource: BadgeDataSource) {

    fun checkAndUnlockDailyLogger(has7DayStreak: Boolean): Boolean {
        return if (has7DayStreak) {
            dataSource.unlockBadge("daily_logger")
        } else false
    }

    fun checkAndUnlockBudgetMaster(stayedWithinBudget: Boolean): Boolean {
        return if (stayedWithinBudget) {
            dataSource.unlockBadge("budget_master")
        } else false
    }

    fun getAllBadges(): List<Badge> = dataSource.getBadges()

    fun getUnlockedBadges(): List<Badge> {
        return dataSource.getBadges().filter { it.isUnlocked }
    }

    fun getBadgeDetails(badgeId: String): Badge? {
        return dataSource.getBadge(badgeId)
    }
}