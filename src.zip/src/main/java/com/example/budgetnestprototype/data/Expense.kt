package com.example.budgetnestprototype.data


import androidx.room.Entity
import androidx.room.PrimaryKey

data class Expense(
    val amount: String = "",
    val category: String = "",
    val date: String = "",
    val description: String = "",
    val photoUri: String? = null
)