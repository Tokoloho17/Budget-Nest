package com.example.budgetnestprototype.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.budgetnestprototype.R
import com.example.budgetnestprototype.data.Expense
import com.example.budgetnestprototype.data.ExpenseRepo
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class ViewExpensesActivity : AppCompatActivity() {

    private lateinit var searchEditText: EditText
    private lateinit var expensesRecyclerView: RecyclerView
    private lateinit var expensesAdapter: ExpensesAdapter

    // Actual expenses list will be populated from your data source
    private var expensesList = mutableListOf<Expense>()
    private lateinit var database: DatabaseReference
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_expenses)

        searchEditText = findViewById(R.id.searchEditText)
        expensesRecyclerView = findViewById(R.id.expensesRecyclerView)
        expensesRecyclerView.layoutManager = LinearLayoutManager(this)
        // Set up the RecyclerView with the ExpensesAdapter
        expensesAdapter = ExpensesAdapter(expensesList)
        expensesRecyclerView.adapter = expensesAdapter

        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().reference

        //Load expenses from Firebase
        LoadExpensesfromFirebase()

        // Filter list as user types
        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val filteredList = expensesList.filter {
                    it.category.contains(s.toString(), ignoreCase = true) ||
                            it.description.contains(s.toString(), ignoreCase = true)
                }
                expensesAdapter.updateExpenses(filteredList)
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

    }

    private fun LoadExpensesfromFirebase() {
        val uid = auth.currentUser?.uid ?: return

        database.child("users").child(uid).child("expenses")
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    expensesList.clear()
                    for (expenseSnap in snapshot.children) {
                        val expense = expenseSnap.getValue(Expense::class.java)
                        if (expense != null) {
                            expensesList.add(expense)
                        }
                    }
                    expensesAdapter.updateExpenses(expensesList)
                }

                override fun onCancelled(error: DatabaseError) {
                    // Log or show error
                }
            })
    }

}
