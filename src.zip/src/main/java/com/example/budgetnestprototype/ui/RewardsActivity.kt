package com.example.budgetnestprototype.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.GridLayoutManager
import com.example.budgetnestprototype.R
import com.example.budgetnestprototype.data.BadgeDataSource
import com.example.budgetnestprototype.data.BadgeManager
import com.example.budgetnestprototype.databinding.ActivityRewardsBinding

class RewardsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRewardsBinding
    private lateinit var badgeManager: BadgeManager

    // Motivational quotes list
    private val motivationalQuotes = listOf(
        "Every rand saved is a step closer to your dream.",
        "Budgeting is telling your money where to go instead of wondering where it went.",
        "Small savings today, big rewards tomorrow.",
        "Track your expenses, take control of your life.",
        "Discipline is the bridge between goals and accomplishment.",
        "Don’t save what is left after spending — spend what is left after saving."
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRewardsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize badge system
        badgeManager = BadgeManager(BadgeDataSource())

        // Setup RecyclerView
        setupBadgeGrid()

        // Show random quote
        binding.quoteText.text = motivationalQuotes.random()

        // Set click listeners
        binding.backArrow.setOnClickListener { finish() }
        binding.btnHome.setOnClickListener { finish() }
    }

    private fun setupBadgeGrid() {
        binding.badgesRecyclerView.apply {
            layoutManager = GridLayoutManager(this@RewardsActivity, 2)
            adapter = BadgeAdapter(badgeManager.getAllBadges())

            // Add divider for spacing
            addItemDecoration(
                DividerItemDecoration(
                    this@RewardsActivity,
                    GridLayoutManager.HORIZONTAL
                ).apply {
                    setDrawable(ContextCompat.getDrawable(context, R.drawable.divider)!!)
                }
            )
        }
    }
}
