package com.example.budgetnestprototype.ui

import android.graphics.Color
import android.graphics.PorterDuff
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.example.budgetnestprototype.R
import androidx.recyclerview.widget.RecyclerView
import com.example.budgetnestprototype.model.Badge

class BadgeAdapter(private val badges: List<Badge>) :
    RecyclerView.Adapter<BadgeAdapter.BadgeViewHolder>() {

    // ViewHolder MUST match  XML IDs
    class BadgeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val icon: ImageView = itemView.findViewById(R.id.badgeIcon)
        val name: TextView = itemView.findViewById(R.id.badgeName)
        val description: TextView = itemView.findViewById(R.id.badgeDescription)
        val status: TextView = itemView.findViewById(R.id.badgeStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BadgeViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_badge, parent, false)
        return BadgeViewHolder(view)
    }

    override fun onBindViewHolder(holder: BadgeViewHolder, position: Int) {
        val badge = badges[position]
        holder.icon.setImageResource(badge.iconResId)
        holder.name.text = badge.name
        holder.description.text = badge.description // This was missing in earlier versions
        holder.status.text = if (badge.isUnlocked) "Unlocked!" else "Locked"
    }

    override fun getItemCount() = badges.size
}