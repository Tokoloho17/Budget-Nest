package com.example.budgetnestprototype

import android.graphics.Color
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.components.LimitLine
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.google.firebase.firestore.FirebaseFirestore
import java.util.*

class ExpenseGraphActivity : AppCompatActivity() {

    private lateinit var barChart: BarChart
    private val db: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }
    private val categoryTotals = mutableMapOf<String, Double>()
    private val categoryGoals = mutableMapOf<String, Pair<Double, Double>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_expense_graph)
        barChart = findViewById(R.id.barChart)
        loadDataAndDrawGraph()
    }

    private fun loadDataAndDrawGraph() {
        val startTime = getStartOfMonth()
        val endTime = System.currentTimeMillis()

        db.collection("expenses")
            .whereGreaterThanOrEqualTo("timestamp", startTime)
            .whereLessThanOrEqualTo("timestamp", endTime)
            .get()
            .addOnSuccessListener { expenseSnapshot ->
                expenseSnapshot.forEach { doc ->
                    val category = doc.getString("category") ?: return@forEach
                    val amount = doc.getDouble("amount") ?: 0.0
                    categoryTotals[category] = categoryTotals.getOrDefault(category, 0.0) + amount
                }
                loadGoals()
            }
            .addOnFailureListener { e ->
                Log.e("ExpenseGraph", "Error loading expenses", e)
            }
    }

    private fun loadGoals() {
        db.collection("goals")
            .get()
            .addOnSuccessListener { goalSnapshot ->
                goalSnapshot.forEach { doc ->
                    val category = doc.getString("category") ?: return@forEach
                    val minGoal = doc.getDouble("minGoal") ?: 0.0
                    val maxGoal = doc.getDouble("maxGoal") ?: 0.0
                    categoryGoals[category] = Pair(minGoal, maxGoal)
                }
                drawBarChart()
            }
            .addOnFailureListener { e ->
                Log.e("ExpenseGraph", "Error loading goals", e)
            }
    }

    private fun drawBarChart() {
        if (categoryTotals.isEmpty()) return

        val entries = categoryTotals.entries.mapIndexed { index, entry ->
            BarEntry(index.toFloat(), entry.value.toFloat())
        }

        val dataSet = BarDataSet(entries, "Spending").apply {
            color = Color.BLUE
            valueTextColor = Color.BLACK
        }

        barChart.apply {
            data = BarData(dataSet)
            xAxis.apply {
                valueFormatter = IndexAxisValueFormatter(categoryTotals.keys.toList())
                position = XAxis.XAxisPosition.BOTTOM
                granularity = 1f
                setDrawGridLines(false)
            }
            axisLeft.apply {
                axisMinimum = 0f
                categoryGoals.values.forEach { (min, max) ->
                    addLimitLine(LimitLine(min.toFloat(), "Min").apply {
                        lineColor = Color.RED
                        lineWidth = 1f
                    })
                    addLimitLine(LimitLine(max.toFloat(), "Max").apply {
                        lineColor = Color.RED
                        lineWidth = 1f
                    })
                }
            }
            axisRight.isEnabled = false
            description.text = "Expense vs Goals"
            setFitBars(true)
            animateY(1000)
            invalidate()
        }
    }

    private fun getStartOfMonth(): Long {
        return Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }
}